from __future__ import annotations

from typing import List
import os
import pandas as pd
from fredapi import Fred
import yfinance as yf

from config import settings


# 需要从 FRED 获取的序列
FRED_SERIES: List[str] = [
    "WALCL",         # Fed Total Assets
    "WTREGEN",       # Treasury General Account (TGA)
    "RRPONTSYD",     # ON RRP (日频)
    "M2SL",          # M2 money stock
    "TOTBKCR",       # Total Bank Credit
    "BUSLOANS",      # Commercial & Industrial Loans
    "EFFR",          # Effective Fed Funds Rate
    "SOFR",          # Secured Overnight Financing Rate
    "BAMLH0A0HYM2",  # HY OAS
    "BAMLC0A0CM",    # IG OAS
]

DATA_DIR = "data"


class DataFetcher:
    """统一管理从 FRED / yfinance 获取数据，并带本地缓存机制。"""

    def __init__(self, api_key: str | None = None):
        if api_key is None:
            api_key = settings.fred_api_key
        if not api_key:
            raise ValueError(
                "FRED API key 未配置。请设置环境变量 FRED_API_KEY，"
                "或在 config.py 中直接填写 Settings.fred_api_key。"
            )
        self.fred = Fred(api_key=api_key)

        # 确保缓存目录存在
        os.makedirs(DATA_DIR, exist_ok=True)

    # --------------- 内部工具：生成缓存路径 ---------------

    def _fred_cache_path(self, weekly_freq: str, start: str, end: str) -> str:
        fname = f"fred_{weekly_freq.replace('-', '')}_{start}_{end}.csv"
        return os.path.join(DATA_DIR, fname)

    def _equity_cache_path(
        self,
        tickers: List[str],
        weekly_freq: str,
        start: str,
        end: str,
    ) -> str:
        tickers_key = "-".join(sorted(tickers))
        fname = f"eq_{tickers_key}_{weekly_freq.replace('-', '')}_{start}_{end}.csv"
        return os.path.join(DATA_DIR, fname)

    # ---------------- FRED 部分 ----------------

    def fetch_fred(
        self,
        series_ids: List[str],
        start: str | None = None,
        end: str | None = None,
        weekly_freq: str = "W-FRI",
        use_cache: bool = True,
    ) -> pd.DataFrame:
        """拉取多条 FRED 序列并聚合为周频，支持本地缓存。"""
        if start is None:
            start = settings.start_date
        if end is None:
            end = settings.end_date

        cache_path = self._fred_cache_path(weekly_freq, start, end)

        if use_cache and os.path.exists(cache_path):
            print(f"[FRED] load from cache: {cache_path}")
            df_w = pd.read_csv(cache_path, index_col=0, parse_dates=[0])
            return df_w

        # 真正从 FRED 下载
        data = {}
        for sid in series_ids:
            print(f"[FRED] downloading {sid} ...")
            s = self.fred.get_series(
                sid,
                observation_start=start,
                observation_end=end,
            )
            data[sid] = s

        df = pd.DataFrame(data)
        df.index = pd.to_datetime(df.index)
        df = df.sort_index()

        # 统一聚合到周频（例如周五）
        df_w = df.resample(weekly_freq).last()

        if use_cache:
            print(f"[FRED] save cache -> {cache_path}")
            df_w.to_csv(cache_path)

        return df_w

    # ---------------- yfinance 部分 ----------------

    def fetch_equity_prices(
        self,
        tickers: List[str],
        start: str | None = None,
        end: str | None = None,
        weekly_freq: str = "W-FRI",
        use_cache: bool = True,
    ) -> pd.DataFrame:
        """从 yfinance 获取资产价格，并聚合为周频收盘价，支持本地缓存。"""
        if start is None:
            start = settings.start_date
        if end is None:
            end = settings.end_date

        cache_path = self._equity_cache_path(tickers, weekly_freq, start, end)

        if use_cache and os.path.exists(cache_path):
            print(f"[YF] load from cache: {cache_path}")
            px_w = pd.read_csv(cache_path, index_col=0, parse_dates=[0])
            return px_w

        print(f"[YF] downloading {tickers} ...")
        px = yf.download(
            tickers,
            start=start,
            end=end,
            auto_adjust=True,
            progress=False,
        )

        # yfinance 返回的列结构一般是多层（OHLCV × ticker）
        if isinstance(px.columns, pd.MultiIndex):
            px = px["Adj Close"]
        else:
            px = px["Adj Close"].to_frame(name=tickers[0])

        px.index = pd.to_datetime(px.index)
        px = px.sort_index()

        px_w = px.resample(weekly_freq).last()

        if use_cache:
            print(f"[YF] save cache -> {cache_path}")
            px_w.to_csv(cache_path)

        return px_w

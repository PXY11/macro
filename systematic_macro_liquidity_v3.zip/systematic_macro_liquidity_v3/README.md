# Systematic Macro Liquidity Strategy (FRED + yfinance)

这是一个最小可运行、可回测、易扩展的 Systematic Macro Liquidity 因子项目。
数据源全部来自：
- FRED（通过 `fredapi`）
- Yahoo Finance（通过 `yfinance`）

当前实现：
- 构建一组基于美联储资产负债表、M2、银行信贷、资金利率、信用利差的 Liquidity 因子
- 合成一个 `F_GlobalLiq` 因子
- 用 `F_GlobalLiq` 在周频上交易 SPY（Systematic Macro Liquidity 策略）
- 简单回测 & 画图
- ✅ 新增：**本地缓存机制**（默认把下载的 FRED & SPY 数据存到 `data/` 目录，下次运行优先读本地，不再重复下载）

## 1. 安装依赖

建议使用 Python 3.10+。

```bash
pip install -r requirements.txt
```

或者使用 mamba / conda：

```bash
mamba create -n macro310 python=3.10 -y
mamba activate macro310
pip install -r requirements.txt
```

## 2. 配置 FRED API Key

方式一：环境变量

```bash
export FRED_API_KEY="YOUR_FRED_API_KEY"
```

Windows (PowerShell)：

```powershell
setx FRED_API_KEY "YOUR_FRED_API_KEY"
```

方式二：直接改 `config.py` 里的 `Settings`，把 `fred_api_key` 字段填上你自己的 key。

## 3. 运行回测

```bash
python main.py
```

程序会：

1. 从 FRED 拉取：WALCL / WTREGEN / RRPONTSYD / M2SL / TOTBKCR / BUSLOANS /
   EFFR / SOFR / BAMLH0A0HYM2 / BAMLC0A0CM（如果 `data/` 下已有缓存，就直接读取）
2. 聚合为周频数据（W-FRI）
3. 计算 Liquidity 因子与 `F_GlobalLiq`
4. 用 yfinance 下载 SPY 周频价格（同样带缓存），构建策略收益并回测
5. 打印回测指标，并画出策略 vs Buy&Hold 的净值曲线

## 4. 目录结构

```text
systematic_macro_liquidity/
├── README.md
├── requirements.txt
├── config.py            # 全局配置（起止日期、FRED API key）
├── data_fetch.py        # 从 FRED / yfinance 拉数据（带本地缓存）
├── factors_liq.py       # 构建 Liquidity 因子与 F_GlobalLiq
├── strategy.py          # 根据因子生成交易信号
├── backtest.py          # 单资产简单回测引擎
├── main.py              # 项目入口：串起来跑一遍
└── data/                # 运行后自动生成，用于保存本地缓存
    ├── fred_WFRI_YYYY-MM-DD_YYYY-MM-DD.csv
    └── eq_SPY_WFRI_YYYY-MM-DD_YYYY-MM-DD.csv
```

## 5. 数据缓存机制说明

- 第一次运行时：
  - `data_fetch.fetch_fred` 会从 FRED 下载数据，并保存到 `data/fred_WFRI_<start>_<end>.csv`
  - `data_fetch.fetch_equity_prices` 会从 yfinance 下载 SPY 数据，并保存到 `data/eq_SPY_WFRI_<start>_<end>.csv`
- 后续运行时（只要 `config.py` 中的 `start_date` / `end_date` 没变）：
  - 如果上述文件存在，代码会打印：
    - `[FRED] load from cache: ...`
    - `[YF] load from cache: ...`
  - 然后直接从本地 CSV 读入，不再对外网请求。

如果你手动修改了 `start_date` / `end_date`，会自动生成对应新文件，不影响旧文件。
如果你想强制重新下载，只需要删除 `data/` 目录下对应缓存文件即可。

## 6. 常见报错排查

1. **`ValueError: FRED API key 未配置`**
   - 确认已经设置环境变量 `FRED_API_KEY`，或者直接修改 `config.py` 中的 `fred_api_key`。

2. **`ValueError: Liquidity 因子全是 NaN`**
   - 通常是：样本太短导致 52 周同比算不出来。
   - 解决：在 `config.py` 中把 `start_date` 设得更早（如 `2005-01-01`）。

3. **`ValueError: 回测结果为空（没有任何有效的 position × return 组合）`**
   - 常见原因：
     - 信号全是 NaN；
     - 价格数据过短或全是 NaN；
     - 价格与信号的时间索引完全不重叠。
   - 建议：
     - 保持 `start_date` 至少在 2005 年或更早；
     - 确认本地能访问 FRED & yfinance（首次运行）。

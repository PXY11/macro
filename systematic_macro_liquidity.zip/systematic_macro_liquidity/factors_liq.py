from __future__ import annotations

import numpy as np
import pandas as pd


def _zscore(series: pd.Series) -> pd.Series:
    """简单 z-score，忽略全 NaN 的情况。"""
    s = series.astype(float)
    mean = s.mean()
    std = s.std()
    if std is None or std == 0 or np.isnan(std):
        return s * 0.0
    return (s - mean) / std


def build_liquidity_factors(fred_df: pd.DataFrame) -> pd.DataFrame:
    """
    根据 FRED 数据构建一组 Liquidity 因子，并输出 z-score 后的结果。

    需要的列：
    - WALCL, WTREGEN, RRPONTSYD
    - M2SL
    - TOTBKCR, BUSLOANS
    - EFFR, SOFR
    - BAMLH0A0HYM2, BAMLC0A0CM
    """

    df = fred_df.copy()

    # --------- 1) 美元系统 Net Liquidity 因子 ---------
    fed_assets = df["WALCL"] / 1000.0     # 转成十亿美元
    tga = df["WTREGEN"] / 1000.0          # TGA 十亿美元
    on_rrp = df["RRPONTSYD"]              # 已经是十亿美元

    netliq_us = fed_assets - tga - on_rrp
    liq_us_yoy = netliq_us.pct_change(52) * 100.0

    # --------- 2) Money / Credit 因子 ---------
    m2_yoy = df["M2SL"].pct_change(52) * 100.0

    totbkcr_yoy = df["TOTBKCR"].pct_change(52) * 100.0
    busloans_yoy = df["BUSLOANS"].pct_change(52) * 100.0
    credit_growth = 0.5 * totbkcr_yoy + 0.5 * busloans_yoy

    # --------- 3) Funding Stress 因子 ---------
    effr = df["EFFR"]
    sofr = df["SOFR"]
    spread_sofr_effr = sofr - effr

    # --------- 4) Credit Spread 因子 ---------
    hy_oas = df["BAMLH0A0HYM2"]
    ig_oas = df["BAMLC0A0CM"]
    hy_ig_spread = hy_oas - ig_oas

    # --------- 汇总原始因子 ---------
    factors_raw = pd.DataFrame(
        {
            "F_Liq_US": liq_us_yoy,
            "F_Money": m2_yoy,
            "F_Credit": credit_growth,
            "F_Funding_Stress": spread_sofr_effr,
            "F_CreditSpread": hy_ig_spread,
        },
        index=df.index,
    )

    # 丢掉完全空行
    factors_raw = factors_raw.dropna(how="all")

    # --------- 做 z-score，并统一方向 ---------
    factors_z = pd.DataFrame(index=factors_raw.index)
    for col in factors_raw.columns:
        factors_z[col] = _zscore(factors_raw[col])

    # 资金紧张类因子：值越高代表越紧 → 做空 Liquidity
    # 我们希望最终 Liquidity 因子越高代表越宽松，因此乘以 -1
    for tight_col in ["F_Funding_Stress", "F_CreditSpread"]:
        if tight_col in factors_z.columns:
            factors_z[tight_col] = -factors_z[tight_col]

    # --------- 合成一个 Global Liquidity 因子 ---------
    cols_for_global = [
        c for c in [
            "F_Liq_US",
            "F_Money",
            "F_Credit",
            "F_Funding_Stress",
            "F_CreditSpread",
        ]
        if c in factors_z.columns
    ]

    factors_z["F_GlobalLiq"] = factors_z[cols_for_global].mean(axis=1)

    return factors_z

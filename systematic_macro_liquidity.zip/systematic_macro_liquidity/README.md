# Systematic Macro Liquidity Strategy (FRED + yfinance)

这是一个最小可运行、可回测、易扩展的 Systematic Macro Liquidity 因子项目。
数据源全部来自：
- FRED（通过 `fredapi`）
- Yahoo Finance（通过 `yfinance`）

当前实现：
- 构建一组基于美联储资产负债表、M2、银行信贷、资金利率、信用利差的 Liquidity 因子
- 合成一个 `F_GlobalLiq` 因子
- 用 `F_GlobalLiq` 在周频上交易 SPY（Systematic Macro Liquidity 策略）
- 简单回测 & 画图

## 1. 安装依赖

建议使用 Python 3.10+。

```bash
pip install -r requirements.txt
```

或者使用 mamba / conda：

```bash
mamba create -n macro310 python=3.10 -y
mamba activate macro310
pip install -r requirements.txt
```

## 2. 配置 FRED API Key

方式一：环境变量

```bash
export FRED_API_KEY="YOUR_FRED_API_KEY"
```

Windows (PowerShell)：

```powershell
setx FRED_API_KEY "YOUR_FRED_API_KEY"
```

方式二：直接改 `config.py` 里的 `Settings`，把 `fred_api_key` 字段填上你自己的 key。

## 3. 运行回测

```bash
python main.py
```

程序会：

1. 从 FRED 拉取：WALCL / WTREGEN / RRPONTSYD / M2SL / TOTBKCR / BUSLOANS /
   EFFR / SOFR / BAMLH0A0HYM2 / BAMLC0A0CM
2. 聚合为周频数据（W-FRI）
3. 计算 Liquidity 因子与 `F_GlobalLiq`
4. 用 yfinance 下载 SPY 周频价格，构建策略收益并回测
5. 打印回测指标，并画出策略 vs Buy&Hold 的净值曲线

## 4. 目录结构

```text
systematic_macro_liquidity/
├── README.md
├── requirements.txt
├── config.py            # 全局配置（起止日期、FRED API key）
├── data_fetch.py        # 从 FRED / yfinance 拉数据
├── factors_liq.py       # 构建 Liquidity 因子与 F_GlobalLiq
├── strategy.py          # 根据因子生成交易信号
├── backtest.py          # 简单回测引擎
└── main.py              # 项目入口：串起来跑一遍
```

## 5. 可扩展点

- 新增 Liquidity 因子：在 `factors_liq.py` 里添加新的列，然后在 `F_GlobalLiq` 的组合里加进去
- 扩展资产：在 `data_fetch.py` 里添加更多 yfinance ticker，把回测逻辑改为多资产组合
- 替换信号逻辑：在 `strategy.py` 里换一个信号函数（例如阈值、回归、打分排序）
- 替换回测框架：`backtest.py` 目前是最简版，可按你自己的投产需求去加手续费、滑点、风险约束等
```

from dataclasses import dataclass
import os
from datetime import datetime


@dataclass
class Settings:
    # 数据起止日期
    start_date: str = "2005-01-01"
    end_date: str = datetime.today().strftime("%Y-%m-%d")

    # FRED API Key：优先从环境变量 FRED_API_KEY 读取
    fred_api_key: str = os.getenv("FRED_API_KEY", "")


settings = Settings()

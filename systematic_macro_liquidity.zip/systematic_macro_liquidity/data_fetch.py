from __future__ import annotations

from typing import List
import pandas as pd
from fredapi import Fred
import yfinance as yf

from config import settings


# 需要从 FRED 获取的序列
FRED_SERIES: List[str] = [
    "WALCL",         # Fed Total Assets
    "WTREGEN",       # Treasury General Account (TGA)
    "RRPONTSYD",     # ON RRP (日频)
    "M2SL",          # M2 money stock
    "TOTBKCR",       # Total Bank Credit
    "BUSLOANS",      # Commercial & Industrial Loans
    "EFFR",          # Effective Fed Funds Rate
    "SOFR",          # Secured Overnight Financing Rate
    "BAMLH0A0HYM2",  # HY OAS
    "BAMLC0A0CM",    # IG OAS
]


class DataFetcher:
    """统一管理从 FRED / yfinance 获取数据。"""

    def __init__(self, api_key: str | None = None):
        if api_key is None:
            api_key = settings.fred_api_key
        if not api_key:
            raise ValueError(
                "FRED API key 未配置。请设置环境变量 FRED_API_KEY，"
                "或在 config.py 中直接填写 Settings.fred_api_key。"
            )
        self.fred = Fred(api_key=api_key)

    # ---------------- FRED 部分 ----------------

    def fetch_fred(
        self,
        series_ids: List[str],
        start: str | None = None,
        end: str | None = None,
        weekly_freq: str = "W-FRI",
    ) -> pd.DataFrame:
        """拉取多条 FRED 序列并聚合为周频。"""
        if start is None:
            start = settings.start_date
        if end is None:
            end = settings.end_date

        data = {}
        for sid in series_ids:
            print(f"[FRED] downloading {sid} ...")
            s = self.fred.get_series(
                sid,
                observation_start=start,
                observation_end=end,
            )
            data[sid] = s

        df = pd.DataFrame(data)
        df.index = pd.to_datetime(df.index)
        df = df.sort_index()

        # 统一聚合到周频（例如周五）
        df_w = df.resample(weekly_freq).last()
        return df_w

    # ---------------- yfinance 部分 ----------------

    def fetch_equity_prices(
        self,
        tickers: List[str],
        start: str | None = None,
        end: str | None = None,
        weekly_freq: str = "W-FRI",
    ) -> pd.DataFrame:
        """从 yfinance 获取资产价格，并聚合为周频收盘价。"""
        if start is None:
            start = settings.start_date
        if end is None:
            end = settings.end_date

        print(f"[YF] downloading {tickers} ...")
        px = yf.download(
            tickers,
            start=start,
            end=end,
            auto_adjust=True,
            progress=False,
        )

        # yfinance 返回的列结构可能是多层（如果多个 ticker）
        if isinstance(px.columns, pd.MultiIndex):
            px = px["Adj Close"]
        else:
            px = px["Adj Close"].to_frame(name=tickers[0])

        px.index = pd.to_datetime(px.index)
        px = px.sort_index()

        px_w = px.resample(weekly_freq).last()
        return px_w

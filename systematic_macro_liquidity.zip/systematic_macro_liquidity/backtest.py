from __future__ import annotations

import numpy as np
import pandas as pd


def _max_drawdown(cum_series: pd.Series) -> float:
    """计算最大回撤。"""
    running_max = cum_series.cummax()
    dd = cum_series / running_max - 1.0
    return float(dd.min())


class Backtester:
    """最小可用的单资产回测器。"""

    def __init__(self, prices: pd.Series, signal: pd.Series):
        self.prices = prices.sort_index()
        self.signal = signal.sort_index()

        # 简单价格收益
        self.returns = self.prices.pct_change()

        # 合并数据
        df = pd.concat(
            {
                "price": self.prices,
                "ret": self.returns,
                "signal": self.signal,
            },
            axis=1,
        )
        # 去掉一开始的 NaN
        self.data = df.dropna(how="any")

    def run(self, holding_shift: int = 1) -> pd.DataFrame:
        """
        运行回测：
        - position_t = signal_{t - holding_shift}
        - strategy_ret_t = position_t * ret_t
        """
        df = self.data.copy()
        df["position"] = df["signal"].shift(holding_shift)
        df = df.dropna(subset=["position", "ret"])

        df["strategy_ret"] = df["position"] * df["ret"]
        df["cum_strategy"] = (1.0 + df["strategy_ret"]).cumprod()
        df["cum_buyhold"] = (1.0 + df["ret"]).cumprod()

        return df

    def summary(self, result: pd.DataFrame | None = None) -> dict:
        if result is None:
            result = self.run()

        total_ret = float(result["cum_strategy"].iloc[-1] - 1.0)

        n_periods = len(result)
        if n_periods <= 1:
            ann_ret = np.nan
        else:
            ann_ret = (1.0 + total_ret) ** (52.0 / n_periods) - 1.0

        vol = float(result["strategy_ret"].std() * np.sqrt(52.0))
        sharpe = float(ann_ret / vol) if vol != 0 and not np.isnan(vol) else np.nan
        max_dd = _max_drawdown(result["cum_strategy"])

        return {
            "total_return": total_ret,
            "annual_return": ann_ret,
            "annual_vol": vol,
            "sharpe": sharpe,
            "max_drawdown": max_dd,
            "n_weeks": n_periods,
        }

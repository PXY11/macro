from __future__ import annotations

import matplotlib.pyplot as plt

from config import settings
from data_fetch import DataFetcher, FRED_SERIES
from factors_liq import build_liquidity_factors
from strategy import build_signal
from backtest import Backtester


def main():
    start = settings.start_date
    end = settings.end_date

    print("=== Systematic Macro Liquidity Strategy ===")
    print(f"Data range: {start} -> {end}")

    # ---------- 1) 获取数据（带缓存） ----------
    fetcher = DataFetcher()

    print("\n[1] Fetching FRED data ...")
    fred_df = fetcher.fetch_fred(FRED_SERIES, start, end, weekly_freq="W-FRI", use_cache=True)
    print(f"FRED weekly shape: {fred_df.shape}")
    print(f"FRED weekly index range: {fred_df.index.min()} -> {fred_df.index.max()}")

    print("\n[2] Building liquidity factors ...")
    factors = build_liquidity_factors(fred_df)
    print(f"Factors shape: {factors.shape}")
    print(f"Factors index range: {factors.index.min()} -> {factors.index.max()}")
    print(f"Available factors: {list(factors.columns)}")

    print("\n[3] Fetching SPY prices from yfinance ...")
    prices_df = fetcher.fetch_equity_prices(["SPY"], start, end, weekly_freq="W-FRI", use_cache=True)
    spy = prices_df["SPY"]
    print(f"SPY weekly shape: {spy.shape}")
    print(f"SPY weekly index range: {spy.index.min()} -> {spy.index.max()}")

    # 对齐索引 —— 用因子时间轴与价格时间轴求交集
    common_index = factors.index.intersection(spy.index)
    if len(common_index) == 0:
        raise ValueError(
            "No overlapping dates between factors and price series.\n"
            f"Factors range: {factors.index.min()} -> {factors.index.max()}\n"
            f"Price   range: {spy.index.min()} -> {spy.index.max()}\n"
            "请检查 start_date / end_date 设置，以及本地缓存数据是否合理(必要时删除 data/ 下缓存重新拉数据)。"
        )

    factors_aligned = factors.reindex(common_index).ffill()
    spy_aligned = spy.reindex(common_index)

    print(f"Common weekly samples: {len(common_index)}")


    print("\n[4] Building trading signal from liquidity factors ...")
    signal = build_signal(factors_aligned, target_col="F_GlobalLiq", scale=1.0)
    print(signal.describe())

    # ---------- 2) 回测 ----------
    print("\n[5] Running backtest ...")
    bt = Backtester(spy_aligned, signal)
    result = bt.run(holding_shift=1)
    stats = bt.summary(result)

    print("\nBacktest summary (weekly):")
    print("------------------------------------")
    print(f"Total return:   {stats['total_return']:.2%}")
    print(f"Annual return:  {stats['annual_return']:.2%}")
    print(f"Annual vol:     {stats['annual_vol']:.2%}")
    print(f"Sharpe ratio:   {stats['sharpe']:.2f}")
    print(f"Max drawdown:   {stats['max_drawdown']:.2%}")
    print(f"Sample length:  {stats['n_weeks']} weeks")
    print("------------------------------------")


    # ---------- 3) 画图 ----------
    print("\n[6] Plotting equity curves ...")
    ax = result[["cum_strategy", "cum_buyhold"]].plot(figsize=(10, 5))
    ax.set_title("Systematic Macro Liquidity vs Buy&Hold (SPY)")
    ax.set_ylabel("Growth of $1")
    ax.grid(True)
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()

from __future__ import annotations

import matplotlib.pyplot as plt

from config import settings
from data_fetch import DataFetcher, FRED_SERIES
from factors_liq import build_liquidity_factors
from strategy import build_signal
from backtest import Backtester


def main():
    start = settings.start_date
    end = settings.end_date

    print("=== Systematic Macro Liquidity Strategy (FRED SP500) ===")
    print(f"Data range: {start} -> {end}")

    # ---------- 1) 获取 FRED 数据（带缓存） ----------
    fetcher = DataFetcher()

    print("\n[1] Fetching FRED data ...")
    fred_df = fetcher.fetch_fred(FRED_SERIES, start, end, weekly_freq="W-FRI", use_cache=True)
    print(f"FRED weekly shape: {fred_df.shape}")
    print(f"FRED weekly index range: {fred_df.index.min()} -> {fred_df.index.max()}")

    # ---------- 2) 构建 Liquidity 因子 ----------
    print("\n[2] Building liquidity factors ...")
    factors = build_liquidity_factors(fred_df)
    print(f"Factors shape: {factors.shape}")
    print(f"Factors index range: {factors.index.min()} -> {factors.index.max()}")
    print(f"Available factors: {list(factors.columns)}")

    # ---------- 3) 使用 FRED 的 SP500 作为标的价格 ----------
    if "SP500" not in fred_df.columns:
        raise ValueError("FRED 数据中不包含 SP500 列，无法作为价格。请检查 FRED_SERIES 设置。")

    spx = fred_df["SP500"]
    print("\n[3] Using FRED SP500 as price series ...")
    print(f"SP500 weekly shape: {spx.shape}")
    print(f"SP500 weekly index range: {spx.index.min()} -> {spx.index.max()}")

    # 对齐索引 —— 用因子时间轴与价格时间轴求交集
    common_index = factors.index.intersection(spx.index)
    if len(common_index) == 0:
        raise ValueError(
            "No overlapping dates between factors and SP500 price series.\n"
            f"Factors range: {factors.index.min()} -> {factors.index.max()}\n"
            f"SP500   range: {spx.index.min()} -> {spx.index.max()}\n"
            "请检查 start_date / end_date 设置，以及本地缓存数据是否合理(必要时删除 data/ 下缓存重新拉数据)。"
        )

    factors_aligned = factors.reindex(common_index).ffill()
    spx_aligned = spx.reindex(common_index)

    print(f"Common weekly samples: {len(common_index)}")

    # ---------- 4) 构建交易信号 ----------
    print("\n[4] Building trading signal from liquidity factors ...")
    signal = build_signal(factors_aligned, target_col="F_GlobalLiq", scale=1.0)
    print(signal.describe())

    # ---------- 5) 回测 ----------
    print("\n[5] Running backtest ...")
    bt = Backtester(spx_aligned, signal)
    result = bt.run(holding_shift=1)
    stats = bt.summary(result)

    print("\nBacktest summary (weekly):")
    print("------------------------------------")
    print(f"Total return:   {stats['total_return']:.2%}")
    print(f"Annual return:  {stats['annual_return']:.2%}")
    print(f"Annual vol:     {stats['annual_vol']:.2%}")
    print(f"Sharpe ratio:   {stats['sharpe']:.2f}")
    print(f"Max drawdown:   {stats['max_drawdown']:.2%}")
    print(f"Sample length:  {stats['n_weeks']} weeks")
    print("------------------------------------")

    # ---------- 6) 画图 ----------
    print("\n[6] Plotting equity curves ...")
    ax = result[["cum_strategy", "cum_buyhold"]].plot(figsize=(10, 5))
    ax.set_title("Systematic Macro Liquidity vs Buy&Hold (FRED SP500)")
    ax.set_ylabel("Growth of $1")
    ax.grid(True)
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    main()

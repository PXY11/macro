# Systematic Macro Liquidity Strategy (FRED + yfinance)

这是一个最小可运行、可回测、易扩展的 Systematic Macro Liquidity 因子项目。
数据源全部来自：
- FRED（通过 `fredapi`）
- （可选）Yahoo Finance（通过 `yfinance`，目前主路径不用它，以避免国内网络不稳定导致数据为空）

当前实现：
- 构建一组基于美联储资产负债表、M2、银行信贷、资金利率、信用利差的 Liquidity 因子
- 合成一个 `F_GlobalLiq` 因子
- ✅ 使用 **FRED 的 `SP500` 指数** 作为标的价格（完全不用 yfinance 的 SPY，避免空文件问题）
- 简单回测 & 画图
- 带本地缓存机制（`data/` 目录）
- 对常见数据问题（空数据 / 无重叠区间）给出清晰的报错和 debug 信息

## 1. 安装依赖

建议使用 Python 3.10+。

```bash
pip install -r requirements.txt
```

或者使用 mamba / conda：

```bash
mamba create -n macro310 python=3.10 -y
mamba activate macro310
pip install -r requirements.txt
```

## 2. 配置 FRED API Key

方式一：环境变量

```bash
export FRED_API_KEY="YOUR_FRED_API_KEY"
```

Windows (PowerShell)：

```powershell
setx FRED_API_KEY "YOUR_FRED_API_KEY"
```

方式二：直接改 `config.py` 里的 `Settings`，把 `fred_api_key` 字段填上你自己的 key。

## 3. 运行回测

```bash
python main.py
```

程序会：

1. 从 FRED 拉取核心序列（包括 `SP500`，如果 `data/` 下已有缓存，就直接读取）
2. 聚合为周频数据（W-FRI），并构建 Liquidity 因子 + `F_GlobalLiq`
3. 直接用 FRED 的 `SP500` 周频收盘指数作为标的价格
4. 对齐时间索引，生成交易信号，回测
5. 打印回测指标，并画出策略 vs Buy&Hold 的净值曲线

## 4. 目录结构

```text
systematic_macro_liquidity/
├── README.md
├── requirements.txt
├── config.py            # 全局配置（起止日期、FRED API key）
├── data_fetch.py        # 从 FRED 拉数据（带本地缓存）；保留 yfinance 工具函数备用
├── factors_liq.py       # 构建 Liquidity 因子与 F_GlobalLiq
├── strategy.py          # 根据因子生成交易信号
├── backtest.py          # 单资产简单回测引擎
├── main.py              # 项目入口：串起来跑一遍
└── data/                # 运行后自动生成，用于保存本地缓存
    └── fred_WFRI_YYYY-MM-DD_YYYY-MM-DD.csv
```

现在主路径只依赖 FRED：只要你能访问 FRED，整个项目就能跑起来，不再受 yfinance / Yahoo 的网络波动影响。

如果你以后想要：
- 使用 yfinance 拉 G10 FX / ETF 做多资产策略；
- 使用 yfinance 替代 FRED SP500；

可以直接在 `main.py` 里切回 `fetch_equity_prices()`，代码已经留好，但默认没有启用。

## 5. 常见报错排查

1. **`ValueError: FRED raw data is empty`**
   - FRED 返回为空：
     - 可能是 API key 无效；
     - 或者 start/end 设置不合理（起止太极端）。

2. **`ValueError: Liquidity 因子全是 NaN`**
   - 通常是：样本太短导致 52 周同比算不出来。
   - 解决：在 `config.py` 中把 `start_date` 设得更早（如 `2005-01-01`）。

3. **`ValueError: No overlapping dates between factors and price series`**
   - 说明：Liquidity 因子（周频）和 `SP500` 周频价格没有任何共同日期。
   - 建议：
     - 看终端打印的 index range；
     - 保持 `start_date` 至少在 2005 年或更早；
     - 确认 FRED 数据非空。

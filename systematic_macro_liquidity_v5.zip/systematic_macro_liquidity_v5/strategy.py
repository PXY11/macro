from __future__ import annotations

import numpy as np
import pandas as pd


def build_signal(
    factors: pd.DataFrame,
    target_col: str = "F_GlobalLiq",
    scale: float = 1.0,
) -> pd.Series:
    """
    根据 Liquidity 因子生成交易信号。

    默认：
    - 使用 `F_GlobalLiq` 作为主因子：
      Liquidity 越宽松 → 信号越偏向做多
    - 用 tanh 压缩到 [-1, 1] 区间，方便扩展到多资产组合。
    """

    if target_col not in factors.columns:
        raise ValueError(f"target_col {target_col} 不在因子表中")

    base = factors[target_col].astype(float)

    # 可调节 scale，scale 越大，tanh 的区分度越强
    sig_values = np.tanh(base * scale)
    signal = pd.Series(sig_values, index=factors.index, name="signal")

    return signal
